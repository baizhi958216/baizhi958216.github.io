from genshincheckinhelper.main import run_once

def main_handler(event, context):
    run_once()

