import os

LANGUAGE = os.environ['LANGUAGE'] if os.environ.get('LANGUAGE') else 'en'

